import { useEffect, useState } from "react";
import { NavLink, useOutletContext } from "react-router-dom";
import axios from "axios";
import "./Kategori.css";

const Kategori = () => {
  const [categories, setCategories] = useState([]);
  const [currentpage, setCurrentPage] = useState(1);
  const { search } = useOutletContext();

  useEffect(() => {
    getProductCategories();
  }, []);

  const getProductCategories = async () => {
    try {
      const result = await axios.get(
        `${import.meta.env.VITE_API_URL}/jenis-produk`,
      );
      setCategories(result.data.data);
      //   console.log(categories);
    } catch (error) {
      console.log(error);
    }
  };

  const filterData = categories.filter((category) => {
    return category.nama?.toLowerCase().includes(search.toLowerCase());
  });

  // Untuk Mencari Total Halaman
  const ITEMS_PER_PAGE = 10;
  const totalPages = Math.ceil(filterData.length / ITEMS_PER_PAGE);

  // slice(mulai, selesai)
  const paginatedData = filterData.slice(
    (currentpage - 1) * ITEMS_PER_PAGE,
    currentpage * ITEMS_PER_PAGE,
  );

  useEffect(() => {
    setCurrentPage(1);
  }, [search]);

  const handleDelete = async (uuid) => {
    const msg = window.confirm("Apakah yakin ingin menghapus kategori ini?");
    if (!msg) return;
    try {
      await axios.delete(
        `${import.meta.env.VITE_API_URL}/jenis-produk/${uuid}`,
      );
      getProductCategories();
    } catch (error) {
      console.log(error);
    }
  };

  return (
    <div>
      <div className="kategori-header">
        <h3>Daftar Kategori</h3>
        <NavLink to={"/dashboard/kategori/add"} className="btn-tambah">
          Tambah Kategori
        </NavLink>
      </div>

      <div className="table-wrapper">
        <table>
          <thead>
            <tr>
              <th>No</th>
              <th>Nama</th>
              <th>Gambar</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody>
            {paginatedData.map((category, index) => (
              <tr key={index}>
                <td>{(currentpage - 1) * ITEMS_PER_PAGE + index + 1}</td>
                <td>{category.nama}</td>
                <td>
                  <img src={category.url} alt="gambar" width={120} />
                </td>
                <td>
                  <button>Edit</button>
                  <button onClick={() => handleDelete(category.uuid)}>
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {/* PAGINATION */}

      {totalPages > 1 && (
        <div className="pagination">
          <button
            className="btn-page"
            disabled={currentpage === 1}
            onClick={() => setCurrentPage((p) => p - 1)}
          >
            &laquo; Prev
          </button>
          {Array.from({ length: totalPages }).map((_, i) => (
            <button
              className="btn-page"
              disabled={currentpage === i + 1}
              key={i}
              onClick={() => setCurrentPage(i + 1)}
            >
              {i + 1}
            </button>
          ))}
          <button
            className="btn-page"
            disabled={currentpage === totalPages}
            onClick={() => setCurrentPage((p) => p + 1)}
          >
            &raquo; Next
          </button>
        </div>
      )}
    </div>
  );
};

export default Kategori;
