import Layanan from "../../components/Layanan/Layanan.jsx";
import Header from "../../components/Header/Header.jsx";

const Layanann = () => {
  return (
    <div>
      <Header />
      <Layanan />
    </div>
  );
};

export default Layanann;
