import Dokter from "../../components/Dokter/Dokter.jsx";
import Header from "../../components/Header/Header.jsx";

const StafDokter = () => {
  return (
    <div>
      <Header />
      <Dokter />
    </div>
  );
};

export default StafDokter;
