import Profile from "../../components/Profile/Profile.jsx";
import Header from "../../components/Header/Header.jsx";

const About = () => {
  return (
    <div>
      <Header />
      <Profile />
    </div>
  );
};

export default About;
