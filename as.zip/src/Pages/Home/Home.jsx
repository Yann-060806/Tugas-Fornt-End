import Header from "../../components/Header/Header.jsx";
import Hero from "../../components/Hero/Hero.jsx";
import Profile from "../../components/Profile/Profile.jsx";
import Dokter from "../../components/Dokter/Dokter.jsx";
import Layanan from "../../components/Layanan/Layanan.jsx";
import Footer from "../../components/Footer/Footer.jsx";

const Home = () => {
  return (
    <div>
      <Header />
      <Hero />
      <Profile />
      <Dokter />
      <Layanan />
      <Footer />
    </div>
  );
};

export default Home;
